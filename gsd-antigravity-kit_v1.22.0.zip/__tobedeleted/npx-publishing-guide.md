# NPM Publishing Guide for `gsd-antigravity-kit`

This guide explains how to publish this project to the NPM registry so that other users can use it via `npx gsd-antigravity-kit`.

## 1. Prerequisites
- An account on [npmjs.com](https://www.npmjs.com/).
- Node.js and npm installed locally.

## 2. Prepare the Package

### Verify `package.json`
Ensue the `bin` field correctly points to the installer script. In our case:
```json
"bin": {
  "gsd-antigravity-kit": "bin/install.js"
}
```

### Shebang Line
The entry point file (`bin/install.js`) MUST start with this line to be executable on Linux/macOS environments:
```javascript
#!/usr/bin/env node
```

## 3. Login to NPM
Run the following command in your terminal:
```bash
npm login
```
This will open a browser window for you to authenticate.

## 4. Strategic Versioning
Before publishing, you must bump the version number. You can use:
```bash
# For small fixes (1.0.2 -> 1.0.3)
npm version patch

# For new features (1.0.2 -> 1.1.0)
npm version minor

# For breaking changes (1.0.2 -> 2.0.0)
npm version major
```
*Note: This command will automatically update `package.json` and create a git tag.*

## 5. Publish to the Registry
If your package name (`gsd-antigravity-kit`) is available and not taken by someone else:
```bash
npm publish
```

### If you are using a scoped package (e.g., `@your-username/gsd-antigravity-kit`):
You must publish with public access:
```bash
npm publish --access public
```

## 6. Verification
Once published, any user can run the installer in their own project directory without installing it globally:

```bash
npx gsd-antigravity-kit
```

### How `npx` works here:
1. `npx` looks for the package `gsd-antigravity-kit` on npm.
2. It downloads the package to a temporary cache.
3. It looks for the command named `gsd-antigravity-kit` defined in the `bin` section of the package's `package.json`.
4. It executes the mapped script (`bin/install.js`) using Node.js.

## 7. Troubleshooting
- **403 Forbidden**: Usually means the package name is already taken or you don't have permissions to update it.
- **ENEEDAUTH**: You are not logged in. Run `npm login`.
- **OTP Required**: If you have 2FA enabled on NPM, it will prompt you for a code during `npm publish`.
